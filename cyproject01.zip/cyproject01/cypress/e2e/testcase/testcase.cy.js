import ProductsPage from '../pages/products.js'

describe('Actions', ()=> {

    const productsPage = new ProductsPage();
   
    it('Add Product', ()=> {
        cy.visit('/')
       productsPage.addProductandVerify();

        })     
    })

